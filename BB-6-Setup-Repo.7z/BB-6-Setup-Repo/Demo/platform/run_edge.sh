#!/usr/bin/env bash

mvn -pl edge package -Prun-edge