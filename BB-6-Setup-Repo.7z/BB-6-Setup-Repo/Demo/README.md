# Backbase Project 

This project is created by http://start.backbase.com 

## README files

- [Backbase 6 :: Platform](platform/README.md)
- [CX 6.0.x series](cx6/README.md)
- [Backbase 6 :: Statics](statics/README.md)
